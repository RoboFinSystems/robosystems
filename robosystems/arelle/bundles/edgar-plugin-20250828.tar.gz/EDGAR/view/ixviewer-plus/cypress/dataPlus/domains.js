export const urls = {
    localRoot: 'http://localhost:3000/',
    secRoot: 'https://www.sec.gov/ixviewer-plus/'
}