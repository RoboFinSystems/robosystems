export const filings = {
	"status": "failed",
	"failures": 1,
	"message": "Could not find Cypress test run results"
}