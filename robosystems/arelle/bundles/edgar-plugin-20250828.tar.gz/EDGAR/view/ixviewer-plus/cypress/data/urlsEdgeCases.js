export const secUrls = [
	"https://www.sec.gov/ix?doc=https://www.sec.gov/Archives/edgar/data/928054/000092805423000097/usgaap-20230606.htm", // 8-k8-k
	"https://www.sec.gov/ix?doc=https://www.sec.gov/Archives/edgar/data/1512886/000116169723000341/form_10-k.htm", // 10-k10-k
	"https://www.sec.gov/ix?doc=https://www.sec.gov/Archives/edgar/data/1409493/000115752323000928/a53410499.htm", // no ticker in url
	"https://www.sec.gov/ix?doc=https://www.sec.gov/Archives/edgar/data/1183765/000117184323003682/f8k_060123.htm",
]