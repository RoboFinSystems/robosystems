// Can use this to scrape /ix.xhtml for more data... if you find a reason to do so.

describe.skip('scrape filings data', () => {
    it('', ()=>{
        cy.visit('http://localhost:3000/ix.xhtml')
    })
})