// status_2900_of_2901
const filing = {
	"version": "2.2",
	"instance_file": "ftre-20230612.htm",
	"link": "?doc=filings/0001965040-23-000005/ftre-20230612.htm",
	"size": false,
	"sec": "https://www.sec.gov/Archives/edgar/data/1965040/000196504023000005/ftre-20230612.htm",
	"secUrl": "https://www.sec.gov/ix?doc=https://www.sec.gov/Archives/edgar/data/1965040/000196504023000005/ftre-20230612.htm",
	"cik": "1965040",
	"accessionNum": "000196504023000005",
	"ticker": "ftre",
	"dateString": "20230612",
	"formType": "8-K",
	"factCount": 23
}